//
//  KKViewController.h
//  KKAnimationgMenu
//
//  Created by SunKe on 13-11-4.
//  Copyright (c) 2013年 Coneboy_K. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KKAnimationgMenu.h"


@interface KKViewController : UIViewController<kkAnimationgMenuDelegate>


@end
